MathForDummies
==============

Este es el PPI del politecnico
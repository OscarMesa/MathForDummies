<?php
function Hola(){
echo 'hola';}
?>

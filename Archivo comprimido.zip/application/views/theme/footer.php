</section>
<div class="clear"></div>
</div>
<footer id="pagefooter">

<div id="footerwrap">

<div id="about">

<h2>Quienes somos?</h2>
<div class="about-text">
<p>

Las Tecnologías de Información y las organizaciones, dan lugar a laimplementación 
de una enorme cantidad de servicios y/o productos, ypresentan una gran expectativa de 
crecimiento y demanda en la industria delInternet y desarrollo de sistemas computarizados (software) <a href="/about"> Leer mas. </a></p>

</div>
</div>
<div id="services">
<h2>Cursos</h2>
<ul>

  <li>Pre-Calculo</li>
  <li>Suma</li>
  <li>Resata</li>
  <li>División</li>
  <li>Polinomios</li>
  <li>Fracciones</li>
</ul>
</div>
<div id="tools">
<h2>Contenidos</h2>
<ul>

  <li>Videos</li>
    <li>Ejercicios</li>
    <li>Talleres</li>
    <li>Foros</li>
    <li>Chat</li>
    <li>Preguta al profé</li>
</ul>
</div>
<div class="clear"></div>
</div>
<div id="credits">
2012 &copy; MathForDummies.com | Kimera |  By Quimera.kf </div>
</footer>
</body>
</html>
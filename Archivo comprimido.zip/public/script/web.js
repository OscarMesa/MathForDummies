function mostrarocultar(a,b)
{
$("."+b).fadeOut(100);
	$("#"+a).fadeIn(900);
}
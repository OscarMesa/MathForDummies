INSERT INTO `materias` (`idmaterias`, `nombre_materia`, `state_materia`, `idarea`) VALUES (1, 'Matemáticas básicas ', 'active', 5);
INSERT INTO `materias` (`idmaterias`, `nombre_materia`, `state_materia`, `idarea`) VALUES (2, 'Español', 'active', 1);
INSERT INTO `materias` (`idmaterias`, `nombre_materia`, `state_materia`, `idarea`) VALUES (3, 'Fisica', 'active', 1);
INSERT INTO `materias` (`idmaterias`, `nombre_materia`, `state_materia`, `idarea`) VALUES (4, 'Quimica', 'active', 1);
INSERT INTO `materias` (`idmaterias`, `nombre_materia`, `state_materia`, `idarea`) VALUES (5, 'Bilogia', 'active', 1);
INSERT INTO `materias` (`idmaterias`, `nombre_materia`, `state_materia`, `idarea`) VALUES (6, 'Inglés', 'active', 1);
INSERT INTO `materias` (`idmaterias`, `nombre_materia`, `state_materia`, `idarea`) VALUES (7, 'Geometría', 'active', 5);
INSERT INTO `materias` (`idmaterias`, `nombre_materia`, `state_materia`, `idarea`) VALUES (8, 'Español', 'active', 4);

INSERT INTO `area` (`id_area`, `descripcion`, `idestado`) VALUES (1, 'Ciencias Naturales 1', 1);
INSERT INTO `area` (`id_area`, `descripcion`, `idestado`) VALUES (2, 'Ciencias Sociales', 1);
INSERT INTO `area` (`id_area`, `descripcion`, `idestado`) VALUES (3, 'Educación Artística', 1);
INSERT INTO `area` (`id_area`, `descripcion`, `idestado`) VALUES (4, 'Humanidades', 1);
INSERT INTO `area` (`id_area`, `descripcion`, `idestado`) VALUES (5, 'Matemáticas', 1);
INSERT INTO `area` (`id_area`, `descripcion`, `idestado`) VALUES (6, 'Tegnología e Informática', 1);
